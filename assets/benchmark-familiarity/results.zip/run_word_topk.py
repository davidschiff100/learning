"""Rank literal-space words in a shared, tokenizer-neutral candidate vocabulary.

The target and every candidate must be encoded as exactly one token by both
models.  This makes top-k membership comparable across tokenizers.  Words that
need multiple tokens in either model are excluded and reported as coverage,
not counted as misses.
"""
import argparse
import gc
import json
import os
import re
import time
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(__file__).resolve().parents[1]
MODEL_NAMES = ["owt_gpt2", "ufw_minicpm"]


def canonical_space_words(tokenizer):
    """Map decoded ``' '+word`` strings to canonical one-token ids."""
    result = {}
    for token_id in range(len(tokenizer)):
        value = tokenizer.decode(
            [token_id], clean_up_tokenization_spaces=False,
            skip_special_tokens=False,
        )
        if len(value) < 2 or value[0] != " " or any(c.isspace() for c in value[1:]):
            continue
        if tokenizer.encode(value, add_special_tokens=False) == [token_id]:
            result[value] = token_id
    return result


def word_spans(text):
    """Return literal-space-delimited words after the first segment."""
    return [(m.start(), m.end(), m.group()[1:]) for m in re.finditer(r" [^ ]+", text)]


@torch.inference_mode()
def score_item(model, tokenizer, candidate_ids, shared_words, item, device):
    text = item["text"]
    encoded = tokenizer(text, add_special_tokens=False, return_offsets_mapping=True)
    ids = encoded["input_ids"]
    offsets = encoded["offset_mapping"]
    if len(ids) < 2:
        return None
    inputs = torch.tensor([ids], device=device)
    logits = model(input_ids=inputs, use_cache=False).logits[0, :-1]
    offset_to_index = {tuple(span): i for i, span in enumerate(offsets)}
    candidate_ids = candidate_ids.to(device)
    eligible = []
    total_suffix_words = 0
    cut_word = max(1, min(len(text.split(" ")) - 1, int(len(text.split(" ")) * .5)))
    suffix_start = len(" ".join(text.split(" ")[:cut_word]))
    for start, end, word in word_spans(text):
        if start < suffix_start:
            continue
        total_suffix_words += 1
        key = " " + word
        token_index = offset_to_index.get((start, end))
        if key not in shared_words or token_index is None or token_index == 0:
            continue
        target_position = shared_words[key]
        if ids[token_index] != candidate_ids[target_position].item():
            raise AssertionError("Full-context token differs from canonical word token")
        values = logits[token_index - 1].index_select(0, candidate_ids)
        top10 = torch.topk(values, k=min(10, values.numel())).indices.tolist()
        rank = top10.index(target_position) + 1 if target_position in top10 else 11
        eligible.append({"word": word, "start": start, "rank_capped_11": rank})
    if not total_suffix_words:
        return None
    return {
        "model": item["model_name"],
        "item_id": item["id"],
        "group": item["group"],
        "benchmark": item["benchmark"],
        "cluster": item["cluster"],
        "suffix_words": total_suffix_words,
        "eligible_words": len(eligible),
        "coverage": len(eligible) / total_suffix_words,
        "top1_hits": sum(x["rank_capped_11"] <= 1 for x in eligible),
        "top5_hits": sum(x["rank_capped_11"] <= 5 for x in eligible),
        "top10_hits": sum(x["rank_capped_11"] <= 10 for x in eligible),
        "top1_accuracy": (sum(x["rank_capped_11"] <= 1 for x in eligible) / len(eligible)) if eligible else None,
        "top5_accuracy": (sum(x["rank_capped_11"] <= 5 for x in eligible) / len(eligible)) if eligible else None,
        "top10_accuracy": (sum(x["rank_capped_11"] <= 10 for x in eligible) / len(eligible)) if eligible else None,
        "word_results": eligible,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--seconds", type=int, default=3300)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic()
    deadline = started + args.seconds
    torch.set_num_threads(4)
    tokenizers = {
        name: AutoTokenizer.from_pretrained(ROOT / "data/models" / name, local_files_only=True, use_fast=True)
        for name in MODEL_NAMES
    }
    maps = {name: canonical_space_words(tok) for name, tok in tokenizers.items()}
    common = sorted(set(maps[MODEL_NAMES[0]]) & set(maps[MODEL_NAMES[1]]))
    shared_index = {word: i for i, word in enumerate(common)}
    candidate_ids = {
        name: torch.tensor([maps[name][word] for word in common], dtype=torch.long)
        for name in MODEL_NAMES
    }
    (args.output / "vocabulary.json").write_text(json.dumps({
        "definition": "Intersection of canonical single-token strings decoded as one leading ASCII space followed by no whitespace.",
        "size": len(common), "sha256": __import__("hashlib").sha256("\n".join(common).encode()).hexdigest(),
    }, indent=2), encoding="utf-8")
    items = json.loads(args.input.read_text(encoding="utf-8"))
    output = args.output / "scores.jsonl"
    output.write_text("", encoding="utf-8")
    with output.open("a", encoding="utf-8") as handle:
        for name in MODEL_NAMES:
            model = AutoModelForCausalLM.from_pretrained(
                ROOT / "data/models" / name, local_files_only=True,
                torch_dtype=torch.float16, attn_implementation="eager",
            ).to("cuda").eval()
            for number, source in enumerate(items, 1):
                if time.monotonic() > deadline:
                    raise TimeoutError("Word top-k scoring exceeded its time budget")
                item = dict(source, model_name=name)
                row = score_item(model, tokenizers[name], candidate_ids[name], shared_index, item, "cuda")
                if row:
                    handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                if number % 50 == 0:
                    handle.flush()
                    print(name, number, f"elapsed={time.monotonic()-started:.1f}s", flush=True)
            del model
            gc.collect()
            torch.cuda.empty_cache()
    (args.output / "runtime.json").write_text(json.dumps({
        "elapsed_seconds": time.monotonic() - started,
        "limit_seconds": args.seconds,
        "gpu": torch.cuda.get_device_name(0),
        "items": len(items),
        "models": MODEL_NAMES,
    }, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
