"""Analyze exact teacher-forced full-word reconstruction."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results/full_word_topk"
MODELS = ["owt_gpt2", "ufw_minicpm"]
COLORS = {MODELS[0]: "#627587", MODELS[1]: "#00848c"}
LABELS = {MODELS[0]: "Older: OWT GPT-2", MODELS[1]: "Newer: MiniCPM"}
METRICS = {"top1_accuracy": "Top-1", "top5_accuracy": "Top-5", "top10_accuracy": "Top-10"}


def slope(x, y):
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    xc = x-x.mean(axis=-1, keepdims=True); den = (xc*xc).sum(axis=-1)
    return np.divide((xc*y).sum(axis=-1), den,
                     out=np.full_like(den, np.nan, dtype=float), where=den > 0)


def pooled(q, hit):
    return q[hit].sum()/q.words.sum()


def paired_advantage(frame, group, hit, rng, draws=10000):
    q = frame[frame.group == group].groupby(["model", "cluster"])[[hit, "words"]].sum().reset_index()
    h = q.pivot(index="cluster", columns="model", values=hit).dropna()
    d = q.pivot(index="cluster", columns="model", values="words").loc[h.index]
    assert (d[MODELS[0]] == d[MODELS[1]]).all()
    idx = rng.integers(0, len(h), (draws, len(h)))
    old = h[MODELS[0]].to_numpy()[idx].sum(1)/d[MODELS[0]].to_numpy()[idx].sum(1)
    new = h[MODELS[1]].to_numpy()[idx].sum(1)/d[MODELS[1]].to_numpy()[idx].sum(1)
    value = h[MODELS[1]].sum()/d[MODELS[1]].sum()-h[MODELS[0]].sum()/d[MODELS[0]].sum()
    return float(value), np.quantile(new-old, [.025, .975])


def cluster_contrast(a, b, hit, rng, draws=10000):
    aa = a.groupby("cluster")[[hit, "words"]].sum().to_numpy()
    bb = b.groupby("cluster")[[hit, "words"]].sum().to_numpy()
    ai = rng.integers(0, len(aa), (draws, len(aa)))
    bi = rng.integers(0, len(bb), (draws, len(bb)))
    av = aa[ai, 0].sum(1)/aa[ai, 1].sum(1)
    bv = bb[bi, 0].sum(1)/bb[bi, 1].sum(1)
    return np.quantile(av-bv, [.025, .975])


def main():
    rng = np.random.default_rng(20260911)
    pilot = pd.read_json(BASE/"prediction/scores.jsonl", lines=True)
    temporal = pd.read_json(BASE/"temporal/scores.jsonl", lines=True)
    for frame in [pilot, temporal]:
        assert not frame.duplicated(["model", "item_id"]).any()
        wide = frame.pivot(index="item_id", columns="model", values="words")
        assert wide.nunique(axis=1).eq(1).all()
        assert (frame.top1_hits <= frame.top5_hits).all()
        assert (frame.top5_hits <= frame.top10_hits).all()
        assert (frame.top10_hits <= frame.words).all()

    summary = []
    for (model, group), q in pilot.groupby(["model", "group"]):
        summary.append({"model": model, "group": group, "items": len(q),
                        "words": int(q.words.sum()), "tokens": int(q.word_tokens.sum()),
                        "tokens_per_word": q.word_tokens.sum()/q.words.sum(),
                        "multi_token_fraction": q.multi_token_words.sum()/q.words.sum(),
                        **{m: pooled(q, m.replace("accuracy", "hits")) for m in METRICS}})
    summary = pd.DataFrame(summary)
    summary.to_csv(BASE/"pilot_summary.csv", index=False)

    advantages = []
    contrasts = []
    groups = ["olmes", "owt_corpus", "ufw_corpus", "iol_english", "iol2026"]
    for group in groups:
        for k in [1, 5, 10]:
            hit = f"top{k}_hits"; value, ci = paired_advantage(pilot, group, hit, rng)
            advantages.append({"group": group, "k": k, "newer_minus_older": value,
                               "ci_low": ci[0], "ci_high": ci[1]})
    for model in MODELS:
        olmes = pilot[(pilot.model == model)&(pilot.group == "olmes")]
        for control in groups[1:]:
            other = pilot[(pilot.model == model)&(pilot.group == control)]
            for k in [1, 5, 10]:
                hit = f"top{k}_hits"; ci = cluster_contrast(olmes, other, hit, rng)
                contrasts.append({"model": model, "control": control, "k": k,
                                  "olmes_minus_control": pooled(olmes, hit)-pooled(other, hit),
                                  "ci_low": ci[0], "ci_high": ci[1]})
    pd.DataFrame(advantages).to_csv(BASE/"pilot_model_advantages.csv", index=False)
    pd.DataFrame(contrasts).to_csv(BASE/"pilot_contrasts.csv", index=False)

    meta = pd.DataFrame(json.loads((ROOT/"data/temporal/manifest.json").read_text()))
    meta["date_years"] = (pd.to_datetime(meta.date)-pd.Timestamp("2018-01-01")).dt.days/365.25
    temporal = temporal.merge(meta[["benchmark", "family", "date", "date_years"]],
                              on="benchmark", validate="many_to_one")
    components = []
    for keys, q in temporal.groupby(["benchmark", "family", "date", "date_years", "model"]):
        row = dict(zip(["benchmark", "family", "date", "date_years", "model"], keys))
        row.update(words=int(q.words.sum()), tokens=int(q.word_tokens.sum()),
                   tokens_per_word=q.word_tokens.sum()/q.words.sum(),
                   **{m: pooled(q, m.replace("accuracy", "hits")) for m in METRICS})
        components.append(row)
    components = pd.DataFrame(components)
    components.to_csv(BASE/"temporal_components.csv", index=False)
    families = components.groupby(["family", "date", "date_years", "model"])[list(METRICS)].mean().reset_index()
    stats = []
    for metric in METRICS:
        p = families.pivot(index=["family", "date", "date_years"], columns="model", values=metric).reset_index()
        p["difference"] = p[MODELS[1]]-p[MODELS[0]]
        x = p.date_years.to_numpy(); idx = rng.integers(0, len(p), (10000, len(p)))
        bs = slope(x[idx], p.difference.to_numpy()[idx]); ci = np.nanquantile(bs, [.025, .975])
        stats.append({"metric": metric, "old_slope": float(slope(x, p[MODELS[0]])),
                      "new_slope": float(slope(x, p[MODELS[1]])),
                      "advantage_slope": float(slope(x, p.difference)),
                      "ci_low": float(ci[0]), "ci_high": float(ci[1]),
                      "families": len(p), "valid_bootstraps": int(np.isfinite(bs).sum())})
    (BASE/"temporal_statistics.json").write_text(json.dumps(stats, indent=2))

    order = ["olmes", "owt_corpus", "ufw_corpus", "iol_english", "iol2026"]
    display = ["OLMES", "OWT", "UFW", "IOL English", "IOL mixed"]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    for ax, metric in zip(axes, METRICS):
        for offset, model in [(-.17, MODELS[0]), (.17, MODELS[1])]:
            q = summary[summary.model == model].set_index("group").reindex(order)
            ax.bar(np.arange(len(order))+offset, 100*q[metric], .34, color=COLORS[model], label=LABELS[model])
        ax.set_xticks(range(len(order)), display, rotation=20)
        ax.set_ylim(0, 100); ax.set_title(METRICS[metric], fontweight="bold")
        ax.set_ylabel("Exact full-word reconstruction (%)")
        ax.grid(axis="y", alpha=.18); ax.spines[["top", "right"]].set_visible(False)
    axes[0].legend(frameon=False, fontsize=8)
    fig.suptitle("Teacher-forced reconstruction of complete space-delimited words", fontsize=16, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, .94]); fig.savefig(BASE/"pilot_full_word_topk.png", dpi=180); plt.close(fig)

    family_plot = families.copy(); family_plot["plot_year"] = 2018+family_plot.date_years
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.6), sharey=True)
    for ax, metric in zip(axes, METRICS):
        for model in MODELS:
            q = family_plot[family_plot.model == model].sort_values("plot_year")
            ax.scatter(q.plot_year, 100*q[metric], s=42, color=COLORS[model])
            coef = np.polyfit(q.plot_year, 100*q[metric], 1); xx = np.linspace(q.plot_year.min(), q.plot_year.max(), 100)
            ax.plot(xx, np.polyval(coef, xx), color=COLORS[model], lw=2.4, label=LABELS[model])
        ax.set_title(METRICS[metric], fontweight="bold"); ax.set_xlabel("First preprint date")
        ax.set_xticks([2018, 2019, 2020]); ax.grid(axis="y", alpha=.18); ax.spines[["top", "right"]].set_visible(False)
    axes[0].set_ylabel("Exact full-word reconstruction (%)"); axes[0].legend(frameon=False, fontsize=8)
    fig.suptitle("Full-word reconstruction by benchmark date", fontsize=16, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, .94]); fig.savefig(BASE/"temporal_full_word_accuracy.png", dpi=180); plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(14, 4.6), sharey=True)
    for ax, metric in zip(axes, METRICS):
        p = families.pivot(index=["family", "date_years"], columns="model", values=metric).reset_index()
        p["plot_year"] = 2018+p.date_years; p["difference"] = 100*(p[MODELS[1]]-p[MODELS[0]])
        stat = next(s for s in stats if s["metric"] == metric)
        ax.scatter(p.plot_year, p.difference, s=48, color="#00848c", zorder=3)
        xx = np.linspace(p.plot_year.min(), p.plot_year.max(), 100); coef = np.polyfit(p.plot_year, p.difference, 1)
        ax.plot(xx, np.polyval(coef, xx), color="#00848c", lw=2.5); ax.axhline(0, color="#7c8a91", lw=1)
        for row in p.itertuples():ax.annotate(row.family, (row.plot_year, row.difference), xytext=(3,4), textcoords="offset points", fontsize=7)
        ax.set_title(f"{METRICS[metric]}: {100*stat['advantage_slope']:+.1f} pp/year", fontweight="bold")
        ax.set_xlabel("First preprint date"); ax.set_xticks([2018, 2019, 2020])
        ax.grid(axis="y", alpha=.18); ax.spines[["top", "right"]].set_visible(False)
    axes[0].set_ylabel("Newer minus older reconstruction (points)")
    fig.suptitle("Does the newer model lose its full-word advantage?", fontsize=16, fontweight="bold")
    fig.text(.5, .01, "A downward trend matches the proposed leakage pattern", ha="center", color="#526a7b")
    fig.tight_layout(rect=[0, .035, 1, .94]); fig.savefig(BASE/"temporal_full_word_advantage.png", dpi=180); plt.close(fig)


if __name__ == "__main__":
    main()
