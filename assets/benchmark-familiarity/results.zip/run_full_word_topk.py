"""Teacher-forced exact reconstruction of every literal-space word.

A word is a top-k hit only when every tokenizer token that composes the full
word is among the model's top-k next-token predictions at its teacher-forced
position.  This includes multi-token words and attached punctuation.
"""
import argparse
import gc
import json
import os
import re
import time
from pathlib import Path

os.environ["HF_HUB_OFFLINE"] = "1"
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

ROOT = Path(__file__).resolve().parents[1]
MODELS = ["owt_gpt2", "ufw_minicpm"]


def suffix_word_spans(text):
    words = text.split(" ")
    if len(words) < 2:
        return []
    cut_word = max(1, min(len(words)-1, int(len(words)*.5)))
    suffix_start = len(" ".join(words[:cut_word]))
    return [(m.start(), m.end(), m.group()[1:])
            for m in re.finditer(r" [^ ]+", text) if m.start() >= suffix_start]


def token_indices_for_span(offsets, start, end):
    indices = [i for i, (a, b) in enumerate(offsets)
               if i > 0 and b > a and a >= start and b <= end]
    if not indices:
        return []
    covered = set()
    for i in indices:
        a, b = offsets[i]
        covered.update(range(a, b))
    return indices if covered == set(range(start, end)) else []


@torch.inference_mode()
def score_item(model, tokenizer, item, device):
    text = item["text"]
    encoded = tokenizer(text, add_special_tokens=False, return_offsets_mapping=True)
    ids, offsets = encoded["input_ids"], encoded["offset_mapping"]
    if len(ids) < 2:
        return None
    inputs = torch.tensor([ids], device=device)
    logits = model(input_ids=inputs, use_cache=False).logits[0, :-1]
    labels = inputs[0, 1:]
    top = torch.topk(logits, k=10, dim=-1).indices
    token_hits = {
        1: top[:, :1].eq(labels[:, None]).any(-1).cpu().tolist(),
        5: top[:, :5].eq(labels[:, None]).any(-1).cpu().tolist(),
        10: top.eq(labels[:, None]).any(-1).cpu().tolist(),
    }
    results = []
    for start, end, word in suffix_word_spans(text):
        indices = token_indices_for_span(offsets, start, end)
        if not indices:
            continue
        decoded = tokenizer.decode([ids[i] for i in indices], clean_up_tokenization_spaces=False)
        if decoded != text[start:end]:
            raise AssertionError((repr(decoded), repr(text[start:end])))
        row = {"word": word, "start": start, "tokens": len(indices)}
        for k in [1, 5, 10]:
            row[f"top{k}_hit"] = all(token_hits[k][i-1] for i in indices)
        results.append(row)
    if not results:
        return None
    row = {
        "model": item["model_name"], "item_id": item["id"],
        "group": item["group"], "benchmark": item["benchmark"],
        "cluster": item["cluster"], "words": len(results),
        "word_tokens": sum(x["tokens"] for x in results),
        "multi_token_words": sum(x["tokens"] > 1 for x in results),
        "word_results": results,
    }
    for k in [1, 5, 10]:
        hits = sum(x[f"top{k}_hit"] for x in results)
        row[f"top{k}_hits"] = hits
        row[f"top{k}_accuracy"] = hits / len(results)
    return row


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--seconds", type=int, default=3300)
    args = ap.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    started = time.monotonic(); deadline = started + args.seconds
    torch.set_num_threads(4)
    items = json.loads(args.input.read_text(encoding="utf-8"))
    output = args.output / "scores.jsonl"
    output.write_text("", encoding="utf-8")
    with output.open("a", encoding="utf-8") as handle:
        for name in MODELS:
            tokenizer = AutoTokenizer.from_pretrained(ROOT/"data/models"/name,
                                                       local_files_only=True, use_fast=True)
            model = AutoModelForCausalLM.from_pretrained(
                ROOT/"data/models"/name, local_files_only=True, dtype=torch.float16,
                attn_implementation="eager").to("cuda").eval()
            for number, source in enumerate(items, 1):
                if time.monotonic() > deadline:
                    raise TimeoutError("Full-word scoring exceeded its time budget")
                row = score_item(model, tokenizer, dict(source, model_name=name), "cuda")
                if row:
                    handle.write(json.dumps(row, ensure_ascii=False) + "\n")
                if number % 50 == 0:
                    handle.flush()
                    print(name, number, f"elapsed={time.monotonic()-started:.1f}s", flush=True)
            del model
            gc.collect(); torch.cuda.empty_cache()
    (args.output/"runtime.json").write_text(json.dumps({
        "elapsed_seconds": time.monotonic()-started, "limit_seconds": args.seconds,
        "gpu": torch.cuda.get_device_name(0), "items": len(items), "models": MODELS,
        "definition": "A word is a hit iff every composing target token is within token top-k under teacher forcing."
    }, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
