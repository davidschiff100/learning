"""Analyze calibration-free word top-5/top-10 results."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / "results/word_topk"
MODELS = ["owt_gpt2", "ufw_minicpm"]


def slope(x, y):
    x = np.asarray(x, dtype=float); y = np.asarray(y, dtype=float)
    xc = x - x.mean(axis=-1, keepdims=True)
    den = (xc * xc).sum(axis=-1)
    return np.divide((xc * y).sum(axis=-1), den,
                     out=np.full_like(den, np.nan, dtype=float), where=den > 0)


def pooled(frame, hit):
    return frame[hit].sum() / frame.eligible_words.sum()


def cluster_boot_difference(a, b, hit, rng, draws=10000):
    def clustered(x):
        return x.groupby("cluster")[[hit, "eligible_words"]].sum().to_numpy()
    aa, bb = clustered(a), clustered(b)
    ai = rng.integers(0, len(aa), (draws, len(aa)))
    bi = rng.integers(0, len(bb), (draws, len(bb)))
    av = aa[ai, 0].sum(1) / aa[ai, 1].sum(1)
    bv = bb[bi, 0].sum(1) / bb[bi, 1].sum(1)
    return np.quantile(av - bv, [.025, .975])


def paired_model_advantage(frame, group, hit, rng, draws=10000):
    q = frame[frame.group == group].groupby(["model", "cluster"])[[hit, "eligible_words"]].sum().reset_index()
    hits = q.pivot(index="cluster", columns="model", values=hit).dropna()
    den = q.pivot(index="cluster", columns="model", values="eligible_words").loc[hits.index]
    assert (den[MODELS[0]] == den[MODELS[1]]).all()
    idx = rng.integers(0, len(hits), (draws, len(hits)))
    old = hits[MODELS[0]].to_numpy()[idx].sum(1) / den[MODELS[0]].to_numpy()[idx].sum(1)
    new = hits[MODELS[1]].to_numpy()[idx].sum(1) / den[MODELS[1]].to_numpy()[idx].sum(1)
    value = hits[MODELS[1]].sum()/den[MODELS[1]].sum() - hits[MODELS[0]].sum()/den[MODELS[0]].sum()
    return float(value), np.quantile(new-old, [.025, .975])


def main():
    rng = np.random.default_rng(20260911)
    pilot = pd.read_json(BASE / "prediction/scores.jsonl", lines=True)
    temporal = pd.read_json(BASE / "temporal/scores.jsonl", lines=True)
    vocab = json.loads((BASE / "prediction/vocabulary.json").read_text())
    assert vocab == json.loads((BASE / "temporal/vocabulary.json").read_text())
    assert not pilot.duplicated(["model", "item_id"]).any()
    assert not temporal.duplicated(["model", "item_id"]).any()
    for frame in [pilot, temporal]:
        wide = frame.pivot(index="item_id", columns="model", values="eligible_words")
        assert wide.nunique(axis=1).eq(1).all()
        assert (frame.top10_hits >= frame.top5_hits).all()
        assert (frame.top5_hits >= frame.top1_hits).all()
        assert (frame.top10_hits <= frame.eligible_words).all()

    summaries = []
    for (model, group), q in pilot.groupby(["model", "group"]):
        summaries.append({"model": model, "group": group, "items": len(q),
                          "suffix_words": int(q.suffix_words.sum()),
                          "eligible_words": int(q.eligible_words.sum()),
                          "coverage": q.eligible_words.sum()/q.suffix_words.sum(),
                          "top1_accuracy": pooled(q, "top1_hits"),
                          "top5_accuracy": pooled(q, "top5_hits"),
                          "top10_accuracy": pooled(q, "top10_hits")})
    summary = pd.DataFrame(summaries)
    summary.to_csv(BASE / "pilot_summary.csv", index=False)

    contrasts = []
    controls = ["owt_corpus", "ufw_corpus", "iol2026", "iol_english"]
    for model in MODELS:
        olmes = pilot[(pilot.model == model) & (pilot.group == "olmes")]
        for control in controls:
            other = pilot[(pilot.model == model) & (pilot.group == control)]
            for k, hit in [(1, "top1_hits"), (5, "top5_hits"), (10, "top10_hits")]:
                value = pooled(olmes, hit) - pooled(other, hit)
                ci = cluster_boot_difference(olmes, other, hit, rng)
                contrasts.append({"model": model, "control": control, "k": k,
                                  "olmes_minus_control": value,
                                  "ci_low": ci[0], "ci_high": ci[1]})
    pd.DataFrame(contrasts).to_csv(BASE / "pilot_contrasts.csv", index=False)
    advantages = []
    for group in ["olmes", "owt_corpus", "ufw_corpus", "iol2026", "iol_english"]:
        for k, hit in [(1, "top1_hits"), (5, "top5_hits"), (10, "top10_hits")]:
            value, ci = paired_model_advantage(pilot, group, hit, rng)
            advantages.append({"group": group, "k": k, "newer_minus_older": value,
                               "ci_low": ci[0], "ci_high": ci[1]})
    advantages = pd.DataFrame(advantages)
    advantages.to_csv(BASE / "pilot_model_advantages.csv", index=False)

    meta = pd.DataFrame(json.loads((ROOT / "data/temporal/manifest.json").read_text()))
    meta["date_years"] = (pd.to_datetime(meta.date)-pd.Timestamp("2018-01-01")).dt.days/365.25
    temporal = temporal.merge(meta[["benchmark", "family", "date", "date_years"]],
                              on="benchmark", validate="many_to_one")
    components = []
    for keys, q in temporal.groupby(["benchmark", "family", "date", "date_years", "model"]):
        row = dict(zip(["benchmark", "family", "date", "date_years", "model"], keys))
        row.update(eligible_words=int(q.eligible_words.sum()),
                   top1_accuracy=pooled(q, "top1_hits"),
                   top5_accuracy=pooled(q, "top5_hits"),
                   top10_accuracy=pooled(q, "top10_hits"))
        components.append(row)
    components = pd.DataFrame(components)
    components.to_csv(BASE / "temporal_components.csv", index=False)
    families = components.groupby(["family", "date", "date_years", "model"])[
        ["top1_accuracy", "top5_accuracy", "top10_accuracy"]].mean().reset_index()
    stats = []
    for metric in ["top1_accuracy", "top5_accuracy", "top10_accuracy"]:
        p = families.pivot(index=["family", "date", "date_years"], columns="model", values=metric).reset_index()
        p["difference"] = p[MODELS[1]] - p[MODELS[0]]
        x = p.date_years.to_numpy(); diff = p.difference.to_numpy()
        indices = rng.integers(0, len(p), (10000, len(p)))
        bs = slope(x[indices], diff[indices])
        ci = np.nanquantile(bs, [.025, .975])
        stats.append({"metric": metric, "old_slope": float(slope(x, p[MODELS[0]])),
                      "new_slope": float(slope(x, p[MODELS[1]])),
                      "advantage_slope": float(slope(x, diff)),
                      "ci_low": float(ci[0]), "ci_high": float(ci[1]),
                      "families": len(p), "valid_bootstraps": int(np.isfinite(bs).sum())})
    (BASE / "temporal_statistics.json").write_text(json.dumps(stats, indent=2))

    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    colors = {"owt_gpt2": "#627587", "ufw_minicpm": "#007c83"}
    labels = {"owt_gpt2": "Older: OWT GPT-2", "ufw_minicpm": "Newer: MiniCPM"}
    groups = ["olmes", "owt_corpus", "ufw_corpus", "iol_english", "iol2026"]
    for ax, k in zip(axes, [1, 5, 10]):
        metric = f"top{k}_accuracy"
        for offset, model in [(-.17, MODELS[0]), (.17, MODELS[1])]:
            q = summary[summary.model == model].set_index("group").reindex(groups)
            ax.bar(np.arange(len(groups))+offset, 100*q[metric], width=.34,
                   color=colors[model], label=labels[model])
        ax.set_xticks(range(len(groups)), ["OLMES", "OWT", "UFW", "IOL English", "IOL mixed"], rotation=20)
        ax.set_ylabel("Eligible-word accuracy (%)")
        ax.set_title(f"Top-{k}")
        ax.set_ylim(0, 100)
    axes[0].legend(fontsize=8)
    fig.suptitle("Exact next-word prediction within the shared one-token vocabulary")
    fig.tight_layout()
    fig.savefig(BASE / "pilot_word_topk.png", dpi=180)
    plt.close(fig)

    metric_labels = {"top1_accuracy": "Top-1", "top5_accuracy": "Top-5", "top10_accuracy": "Top-10"}
    model_labels = {MODELS[0]: "Older: OWT GPT-2", MODELS[1]: "Newer: MiniCPM"}
    family_plot = families.copy()
    family_plot["plot_year"] = 2018 + family_plot.date_years

    fig, axes = plt.subplots(1, 3, figsize=(14, 4.6), sharey=True)
    for ax, metric in zip(axes, metric_labels):
        for model in MODELS:
            q = family_plot[family_plot.model == model].sort_values("plot_year")
            ax.scatter(q.plot_year, 100*q[metric], s=42, color=colors[model], alpha=.9)
            coef = np.polyfit(q.plot_year, 100*q[metric], 1)
            xx = np.linspace(q.plot_year.min(), q.plot_year.max(), 100)
            ax.plot(xx, np.polyval(coef, xx), color=colors[model], lw=2.4, label=model_labels[model])
        ax.set_title(metric_labels[metric], fontweight="bold")
        ax.set_xlabel("First preprint date")
        ax.set_xticks([2018, 2019, 2020])
        ax.grid(axis="y", alpha=.18)
        ax.spines[["top", "right"]].set_visible(False)
    axes[0].set_ylabel("Eligible-word accuracy (%)")
    axes[0].legend(frameon=False, fontsize=8, loc="lower right")
    fig.suptitle("Question-word prediction by benchmark date", fontsize=16, fontweight="bold")
    fig.tight_layout(rect=[0, 0, 1, .94])
    fig.savefig(BASE / "temporal_word_accuracy.png", dpi=180)
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(14, 4.6), sharey=True)
    for ax, metric in zip(axes, metric_labels):
        p = families.pivot(index=["family", "date_years"], columns="model", values=metric).reset_index()
        p["plot_year"] = 2018 + p.date_years
        p["difference"] = 100*(p[MODELS[1]]-p[MODELS[0]])
        stat = next(s for s in stats if s["metric"] == metric)
        ax.scatter(p.plot_year, p.difference, s=48, color="#007c83", zorder=3)
        xx = np.linspace(p.plot_year.min(), p.plot_year.max(), 100)
        coef = np.polyfit(p.plot_year, p.difference, 1)
        ax.plot(xx, np.polyval(coef, xx), color="#007c83", lw=2.5)
        ax.axhline(0, color="#7c8a91", lw=1)
        for row in p.itertuples():
            ax.annotate(row.family, (row.plot_year, row.difference), xytext=(3, 4),
                        textcoords="offset points", fontsize=7)
        ax.set_title(f"{metric_labels[metric]}: {100*stat['advantage_slope']:+.1f} pp/year", fontweight="bold")
        ax.set_xlabel("First preprint date")
        ax.set_xticks([2018, 2019, 2020])
        ax.grid(axis="y", alpha=.18)
        ax.spines[["top", "right"]].set_visible(False)
    axes[0].set_ylabel("Newer minus older accuracy (percentage points)")
    fig.suptitle("Does the newer model lose its word-prediction advantage?", fontsize=16, fontweight="bold")
    fig.text(.5, .01, "A downward trend matches the proposed leakage pattern", ha="center", color="#526a7b")
    fig.tight_layout(rect=[0, .035, 1, .94])
    fig.savefig(BASE / "temporal_word_advantage.png", dpi=180)
    plt.close(fig)

    lines = [
        "# Word-level top-k robustness experiment", "",
        f"The shared candidate vocabulary contains **{vocab['size']:,}** literal-space words that both models encode as one canonical token. The primary continuation is the final 50% of each text under neutral prompting. At every eligible word boundary, the true next word is tested against the five and ten highest-logit words in this identical vocabulary.", "",
        "Words requiring multiple tokens in either model are excluded rather than counted as misses. This produces a tokenizer-comparable rank statistic and removes probability-scale calibration, but it estimates performance on common single-token words rather than every word in the questions.", "",
        "## Pilot results", "",
        "| Model | Group | Coverage | Top-1 | Top-5 | Top-10 |", "|---|---|---:|---:|---:|---:|",
    ]
    for r in summary.itertuples():
        lines.append(f"| {r.model} | {r.group} | {r.coverage:.1%} | {r.top1_accuracy:.1%} | {r.top5_accuracy:.1%} | {r.top10_accuracy:.1%} |")
    lines += ["", "The newer model exceeds the older model on OLMES by **7.1 percentage points at top-1**, **7.5 at top-5**, and **8.1 at top-10**. It also improves by **10.3 top-1 points and 12.6 top-5 points on the novel English IOL control**, so the OLMES gain by itself cannot separate familiarity from general predictive ability. Relative to each model's own sampled training-corpus control, the OLMES advantage rises from **1.8 to 6.1 top-1 points**, **1.7 to 9.6 top-5 points**, and **0.6 to 7.9 top-10 points**; these corpus excerpts are not genre-matched controls.", "",
              "![Pilot word top-k](pilot_word_topk.png)", "", "## OLMES benchmark-date slopes", "",
              "The temporal analysis gives equal weight to the same nine date families used in the loss experiment. The model advantage is newer minus older accuracy. Under the leakage hypothesis proposed for this experiment, a negative advantage slope would mean that the newer model's relative predictive advantage shrinks on later benchmarks.", "",
              "| Metric | Older slope/year | Newer slope/year | Newer-advantage slope/year | 95% family bootstrap |",
              "|---|---:|---:|---:|---:|"]
    for s in stats:
        lines.append(f"| {s['metric'].replace('_accuracy','').replace('top','Top-')} | {s['old_slope']:+.3f} | {s['new_slope']:+.3f} | {s['advantage_slope']:+.3f} | [{s['ci_low']:+.3f}, {s['ci_high']:+.3f}] |")
    lines += ["", "The intervals are descriptive family bootstraps over only nine heterogeneous benchmark families. As in the loss analysis, benchmark date, domain, writing style, and difficulty are entangled, so the slopes are not membership estimates.", "",
              "## Reproduce", "", "```powershell",
              ".\\.venv\\Scripts\\python.exe scripts/run_word_topk.py --input results/prediction/scored_items.json --output results/word_topk/prediction --seconds 3300",
              ".\\.venv\\Scripts\\python.exe scripts/run_word_topk.py --input results/temporal/scored_items.json --output results/word_topk/temporal --seconds 3300",
              ".\\.venv\\Scripts\\python.exe scripts/analyze_word_topk.py", "```", ""]
    (BASE / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    main()
